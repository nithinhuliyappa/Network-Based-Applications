function myItems()
{window.open("/myItems",'_self',false);}

function items()
{window.open("/items",'_self',false);}

function swap()
{window.open("/swap",'_self',false);}
